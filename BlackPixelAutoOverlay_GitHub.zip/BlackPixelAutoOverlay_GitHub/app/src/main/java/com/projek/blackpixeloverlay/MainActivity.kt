package com.projek.blackpixeloverlay

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Point
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var container: LinearLayout
    private lateinit var layers: MutableList<OverlayLayer>
    private var baseW = 1080
    private var baseH = 2400

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val point = realScreenSize()
        baseW = min(point.x, point.y).coerceAtLeast(1)
        baseH = max(point.x, point.y).coerceAtLeast(1)
        PresetStore.initDefaultsIfNeeded(this, baseW, baseH)

        baseW = PresetStore.getBaseW(this)
        baseH = PresetStore.getBaseH(this)
        layers = PresetStore.readLayers(this)

        maybeAskNotificationPermission()
        renderUi()
    }

    override fun onResume() {
        super.onResume()
        renderUi()
    }

    private fun renderUi() {
        val scroll = ScrollView(this)
        container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(28))
        }
        scroll.addView(container)
        setContentView(scroll)

        addTitle()
        addPermissionBlock()
        addAutoRotateSwitch()

        addSmallText("Base portrait: ${baseW} x ${baseH} px. X/Y/Width/Height disimpan sebagai koordinat portrait, lalu diputar otomatis saat layar rotate.")
        addSpacer(12)

        for (i in 0 until PresetStore.MAX_LAYERS) {
            addLayerEditor(i)
        }

        addSpacer(10)
        addMainButtons()
    }

    private fun addTitle() {
        TextView(this).apply {
            text = "Black Pixel Auto Overlay"
            textSize = 24f
            setTextColor(Color.BLACK)
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, dp(8), 0, dp(6))
            container.addView(this, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        TextView(this).apply {
            text = "Auto rotate + 1 sampai 4 layer hitam"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(0, 0, 0, dp(14))
            container.addView(this, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
    }

    private fun addPermissionBlock() {
        val hasPermission = canDrawOverlay()
        val text = if (hasPermission) {
            "Izin overlay: AKTIF"
        } else {
            "Izin overlay: BELUM AKTIF"
        }

        TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(if (hasPermission) Color.rgb(0, 120, 0) else Color.rgb(180, 0, 0))
            setPadding(0, dp(6), 0, dp(6))
            container.addView(this, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }

        if (!hasPermission) {
            Button(this).apply {
                this.text = "Buka Izin Draw Over Apps"
                setOnClickListener { openOverlayPermissionSettings() }
                container.addView(this, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            }
            addSpacer(10)
        }
    }

    private fun addAutoRotateSwitch() {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(10))
        }

        val label = TextView(this).apply {
            text = "Auto rotate ikut orientasi layar"
            textSize = 16f
            setTextColor(Color.BLACK)
        }
        row.addView(label, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val switch = Switch(this).apply {
            isChecked = PresetStore.getAutoRotate(this@MainActivity)
            setOnCheckedChangeListener { _, checked ->
                PresetStore.setAutoRotate(this@MainActivity, checked)
                notifyOverlayChanged()
            }
        }
        row.addView(switch)
        container.addView(row, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    }

    private fun addLayerEditor(index: Int) {
        val layer = layers[index]
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(245, 245, 245))
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val title = TextView(this).apply {
            text = "Layer ${index + 1}"
            textSize = 18f
            setTextColor(Color.BLACK)
        }
        header.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        val enabledSwitch = Switch(this).apply {
            isChecked = layer.enabled
            setOnCheckedChangeListener { _, checked ->
                layer.enabled = checked
                saveAndRefresh()
            }
        }
        header.addView(enabledSwitch)
        box.addView(header)

        addSlider(box, "Posisi X", 0, baseW, layer.x) { value ->
            layer.x = value
            saveAndRefresh()
        }
        addSlider(box, "Posisi Y", 0, baseH, layer.y) { value ->
            layer.y = value
            saveAndRefresh()
        }
        addSlider(box, "Lebar", 1, baseW, layer.width) { value ->
            layer.width = value.coerceAtLeast(1)
            saveAndRefresh()
        }
        addSlider(box, "Panjang", 1, baseH, layer.height) { value ->
            layer.height = value.coerceAtLeast(1)
            saveAndRefresh()
        }

        val marginParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            bottomMargin = dp(12)
        }
        container.addView(box, marginParams)
    }

    private fun addSlider(
        parent: LinearLayout,
        label: String,
        minValue: Int,
        maxValue: Int,
        initialValue: Int,
        onChanged: (Int) -> Unit
    ) {
        val valueLabel = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.DKGRAY)
            setPadding(0, dp(8), 0, 0)
        }

        val safeMin = minValue.coerceAtLeast(0)
        val safeMax = maxValue.coerceAtLeast(safeMin + 1)
        val safeInitial = initialValue.coerceIn(safeMin, safeMax)
        valueLabel.text = "$label: $safeInitial px"
        parent.addView(valueLabel, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        SeekBar(this).apply {
            max = safeMax - safeMin
            progress = safeInitial - safeMin
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val value = progress + safeMin
                    valueLabel.text = "$label: $value px"
                    if (fromUser) onChanged(value)
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) = Unit
                override fun onStopTrackingTouch(seekBar: SeekBar?) = Unit
            })
            parent.addView(this, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
    }

    private fun addMainButtons() {
        Button(this).apply {
            text = "START BLACK OVERLAY"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.BLACK)
            setOnClickListener { startOverlay() }
            container.addView(this, LinearLayout.LayoutParams.MATCH_PARENT, dp(56))
        }

        addSpacer(8)

        Button(this).apply {
            text = "UPDATE OVERLAY"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(33, 150, 243))
            setOnClickListener {
                saveAndRefresh()
                Toast.makeText(this@MainActivity, "Overlay di-update", Toast.LENGTH_SHORT).show()
            }
            container.addView(this, LinearLayout.LayoutParams.MATCH_PARENT, dp(56))
        }

        addSpacer(8)

        Button(this).apply {
            text = "STOP OVERLAY"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(244, 67, 54))
            setOnClickListener { stopOverlay() }
            container.addView(this, LinearLayout.LayoutParams.MATCH_PARENT, dp(56))
        }

        addSpacer(8)

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Button(this).apply {
            text = "LOAD PRESET"
            setOnClickListener {
                layers = PresetStore.readLayers(this@MainActivity)
                renderUi()
                notifyOverlayChanged()
            }
            row.addView(this, LinearLayout.LayoutParams(0, dp(52), 1f))
        }
        Button(this).apply {
            text = "RESET"
            setOnClickListener {
                PresetStore.resetDefaults(this@MainActivity, baseW, baseH)
                layers = PresetStore.readLayers(this@MainActivity)
                renderUi()
                notifyOverlayChanged()
            }
            row.addView(this, LinearLayout.LayoutParams(0, dp(52), 1f))
        }
        container.addView(row, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
    }

    private fun saveAndRefresh() {
        PresetStore.saveLayers(this, layers)
        notifyOverlayChanged()
    }

    private fun notifyOverlayChanged() {
        sendBroadcast(Intent(OverlayService.ACTION_UPDATE).setPackage(packageName))
    }

    private fun startOverlay() {
        PresetStore.saveLayers(this, layers)
        if (!canDrawOverlay()) {
            Toast.makeText(this, "Aktifkan izin overlay dulu", Toast.LENGTH_SHORT).show()
            openOverlayPermissionSettings()
            return
        }

        val intent = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        notifyOverlayChanged()
        Toast.makeText(this, "Overlay aktif", Toast.LENGTH_SHORT).show()
    }

    private fun stopOverlay() {
        stopService(Intent(this, OverlayService::class.java))
        Toast.makeText(this, "Overlay berhenti", Toast.LENGTH_SHORT).show()
    }

    private fun canDrawOverlay(): Boolean {
        return Build.VERSION.SDK_INT < Build.VERSION_CODES.M || Settings.canDrawOverlays(this)
    }

    private fun openOverlayPermissionSettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun maybeAskNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1001)
        }
    }

    @Suppress("DEPRECATION")
    private fun realScreenSize(): Point {
        val point = Point()
        windowManager.defaultDisplay.getRealSize(point)
        return point
    }

    private fun addSmallText(text: String) {
        TextView(this).apply {
            this.text = text
            textSize = 13f
            setTextColor(Color.GRAY)
            setPadding(0, 0, 0, dp(4))
            container.addView(this, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        }
    }

    private fun addSpacer(heightDp: Int) {
        View(this).apply {
            container.addView(this, LinearLayout.LayoutParams.MATCH_PARENT, dp(heightDp))
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
