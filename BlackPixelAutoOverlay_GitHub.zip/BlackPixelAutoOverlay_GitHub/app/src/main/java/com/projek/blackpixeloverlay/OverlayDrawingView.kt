package com.projek.blackpixeloverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.Surface
import android.view.View
import kotlin.math.max
import kotlin.math.min

class OverlayDrawingView(context: Context) : View(context) {
    private val paint = Paint().apply {
        color = Color.BLACK
        style = Paint.Style.FILL
        isAntiAlias = false
    }

    private var layers: List<OverlayLayer> = emptyList()
    private var baseW = 1080
    private var baseH = 2400
    private var autoRotate = true
    private var displayRotation = Surface.ROTATION_0

    fun reload(rotation: Int) {
        baseW = PresetStore.getBaseW(context).coerceAtLeast(1)
        baseH = PresetStore.getBaseH(context).coerceAtLeast(1)
        autoRotate = PresetStore.getAutoRotate(context)
        layers = PresetStore.readLayers(context)
        displayRotation = rotation
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val currentW = width.toFloat().coerceAtLeast(1f)
        val currentH = height.toFloat().coerceAtLeast(1f)
        val rotation = if (autoRotate) displayRotation else Surface.ROTATION_0

        layers.filter { it.enabled }.forEach { layer ->
            val rect = if (autoRotate) {
                buildAutoRotatedRect(layer, rotation, currentW, currentH)
            } else {
                buildNormalRect(layer, currentW, currentH)
            }
            drawClipped(canvas, rect, currentW, currentH)
        }
    }

    private fun buildNormalRect(layer: OverlayLayer, currentW: Float, currentH: Float): RectF {
        val x = layer.x.toFloat() / baseW * currentW
        val y = layer.y.toFloat() / baseH * currentH
        val w = layer.width.toFloat() / baseW * currentW
        val h = layer.height.toFloat() / baseH * currentH
        return RectF(x, y, x + w, y + h)
    }

    private fun buildAutoRotatedRect(layer: OverlayLayer, rotation: Int, currentW: Float, currentH: Float): RectF {
        val naturalW = if (rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270) currentH else currentW
        val naturalH = if (rotation == Surface.ROTATION_90 || rotation == Surface.ROTATION_270) currentW else currentH

        val x = layer.x.toFloat() / baseW * naturalW
        val y = layer.y.toFloat() / baseH * naturalH
        val w = layer.width.toFloat() / baseW * naturalW
        val h = layer.height.toFloat() / baseH * naturalH

        return when (rotation) {
            Surface.ROTATION_90 -> {
                RectF(
                    currentW - (y + h),
                    x,
                    currentW - y,
                    x + w
                )
            }
            Surface.ROTATION_180 -> {
                RectF(
                    currentW - (x + w),
                    currentH - (y + h),
                    currentW - x,
                    currentH - y
                )
            }
            Surface.ROTATION_270 -> {
                RectF(
                    y,
                    currentH - (x + w),
                    y + h,
                    currentH - x
                )
            }
            else -> RectF(x, y, x + w, y + h)
        }
    }

    private fun drawClipped(canvas: Canvas, source: RectF, maxW: Float, maxH: Float) {
        val left = min(max(source.left, 0f), maxW)
        val top = min(max(source.top, 0f), maxH)
        val right = min(max(source.right, 0f), maxW)
        val bottom = min(max(source.bottom, 0f), maxH)

        if (right > left && bottom > top) {
            canvas.drawRect(left, top, right, bottom, paint)
        }
    }
}
