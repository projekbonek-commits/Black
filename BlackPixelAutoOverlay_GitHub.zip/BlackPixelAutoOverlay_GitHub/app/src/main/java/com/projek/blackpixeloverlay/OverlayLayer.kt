package com.projek.blackpixeloverlay

data class OverlayLayer(
    var enabled: Boolean = false,
    var x: Int = 0,
    var y: Int = 0,
    var width: Int = 5,
    var height: Int = 100
)
