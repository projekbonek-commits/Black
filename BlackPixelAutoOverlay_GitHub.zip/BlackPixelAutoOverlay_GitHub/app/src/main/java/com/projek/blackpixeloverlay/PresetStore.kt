package com.projek.blackpixeloverlay

import android.content.Context
import kotlin.math.max

object PresetStore {
    const val MAX_LAYERS = 4

    private const val PREFS = "black_pixel_overlay_prefs"
    private const val KEY_INITIALIZED = "initialized"
    private const val KEY_BASE_W = "base_w"
    private const val KEY_BASE_H = "base_h"
    private const val KEY_AUTO_ROTATE = "auto_rotate"

    fun initDefaultsIfNeeded(context: Context, baseW: Int, baseH: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getBoolean(KEY_INITIALIZED, false)) return

        val safeW = max(1, baseW)
        val safeH = max(1, baseH)
        val editor = prefs.edit()
            .putBoolean(KEY_INITIALIZED, true)
            .putInt(KEY_BASE_W, safeW)
            .putInt(KEY_BASE_H, safeH)
            .putBoolean(KEY_AUTO_ROTATE, true)

        for (i in 0 until MAX_LAYERS) {
            val enabled = i == 0
            val x = if (i == 0) (safeW * 3 / 4) else (safeW / 2)
            val y = if (i == 0) 0 else (safeH / 3)
            val width = if (i == 0) 5 else 10
            val height = if (i == 0) safeH else (safeH / 3)

            editor
                .putBoolean("layer_${i}_enabled", enabled)
                .putInt("layer_${i}_x", x.coerceIn(0, safeW))
                .putInt("layer_${i}_y", y.coerceIn(0, safeH))
                .putInt("layer_${i}_width", width.coerceIn(1, safeW))
                .putInt("layer_${i}_height", height.coerceIn(1, safeH))
        }

        editor.apply()
    }

    fun resetDefaults(context: Context, baseW: Int, baseH: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().apply()
        initDefaultsIfNeeded(context, baseW, baseH)
    }

    fun getBaseW(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_BASE_W, 1080).coerceAtLeast(1)

    fun getBaseH(context: Context): Int =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_BASE_H, 2400).coerceAtLeast(1)

    fun getAutoRotate(context: Context): Boolean =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_AUTO_ROTATE, true)

    fun setAutoRotate(context: Context, enabled: Boolean) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_AUTO_ROTATE, enabled)
            .apply()
    }

    fun readLayers(context: Context): MutableList<OverlayLayer> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val baseW = getBaseW(context)
        val baseH = getBaseH(context)

        return MutableList(MAX_LAYERS) { i ->
            OverlayLayer(
                enabled = prefs.getBoolean("layer_${i}_enabled", i == 0),
                x = prefs.getInt("layer_${i}_x", baseW / 2).coerceIn(0, baseW),
                y = prefs.getInt("layer_${i}_y", baseH / 2).coerceIn(0, baseH),
                width = prefs.getInt("layer_${i}_width", 5).coerceIn(1, baseW),
                height = prefs.getInt("layer_${i}_height", baseH / 2).coerceIn(1, baseH)
            )
        }
    }

    fun saveLayers(context: Context, layers: List<OverlayLayer>) {
        val baseW = getBaseW(context)
        val baseH = getBaseH(context)
        val editor = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()

        layers.take(MAX_LAYERS).forEachIndexed { i, layer ->
            editor
                .putBoolean("layer_${i}_enabled", layer.enabled)
                .putInt("layer_${i}_x", layer.x.coerceIn(0, baseW))
                .putInt("layer_${i}_y", layer.y.coerceIn(0, baseH))
                .putInt("layer_${i}_width", layer.width.coerceIn(1, baseW))
                .putInt("layer_${i}_height", layer.height.coerceIn(1, baseH))
        }

        editor.apply()
    }
}
