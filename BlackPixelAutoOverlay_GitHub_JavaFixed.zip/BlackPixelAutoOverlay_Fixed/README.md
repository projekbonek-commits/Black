# Black Pixel Auto Overlay - Java Fixed

Versi ini pakai Java + Gradle Android supaya lebih gampang dibuild di GitHub Actions.

Fitur:
- Auto rotate mengikuti orientasi layar.
- Maksimal 4 layer hitam.
- Layer bisa ON/OFF.
- Posisi X/Y dan ukuran lewat slider.
- Overlay pass-through, sentuhan ke aplikasi bawah tetap jalan.

Build:
- Upload isi project ke GitHub, atau upload ZIP lalu pakai workflow extractor.
- Jalankan Actions > Build APK.
- Download artifact BlackPixelAutoOverlay-debug-apk.
