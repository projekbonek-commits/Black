package com.projek.blackpixeloverlay;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY = 1001;
    private int baseW = 1080;
    private int baseH = 2400;
    private LinearLayout root;
    private final TextView[][] labels = new TextView[OverlayConfig.MAX_LAYERS][4];
    private final SeekBar[][] bars = new SeekBar[OverlayConfig.MAX_LAYERS][4];
    private final CheckBox[] checkBoxes = new CheckBox[OverlayConfig.MAX_LAYERS];

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        calculateScreenBase();
        buildUi();
    }

    private void calculateScreenBase() {
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(dm);
        baseW = Math.min(dm.widthPixels, dm.heightPixels);
        baseH = Math.max(dm.widthPixels, dm.heightPixels);
    }

    private void buildUi() {
        ScrollView scrollView = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(24));
        scrollView.addView(root);

        TextView title = text("Black Pixel Auto Overlay", 26, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        TextView subtitle = text("Auto rotate + 1 sampai 4 layer hitam", 15, false);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(4), 0, dp(16));
        root.addView(subtitle);

        Button permission = button("IZINKAN OVERLAY");
        permission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                requestOverlayPermission();
            }
        });
        root.addView(permission);

        for (int i = 0; i < OverlayConfig.MAX_LAYERS; i++) {
            addLayerPanel(i);
        }

        Button start = button("START BLACK OVERLAY");
        start.setTextColor(0xFFFFFFFF);
        start.setBackgroundColor(0xFF000000);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startOverlay();
            }
        });
        root.addView(start);

        Button update = button("UPDATE OVERLAY");
        update.setTextColor(0xFFFFFFFF);
        update.setBackgroundColor(0xFF2196F3);
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                updateOverlay();
            }
        });
        root.addView(update);

        Button stop = button("STOP OVERLAY");
        stop.setTextColor(0xFFFFFFFF);
        stop.setBackgroundColor(0xFFF44336);
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopOverlay();
            }
        });
        root.addView(stop);

        TextView note = text("Tips: kalibrasi di posisi portrait dulu. Nanti saat HP diputar, posisi layer ikut dihitung otomatis.", 13, false);
        note.setPadding(0, dp(14), 0, 0);
        root.addView(note);

        setContentView(scrollView);
    }

    private void addLayerPanel(final int layer) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(12), dp(12), dp(12));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        p.setMargins(0, dp(12), 0, dp(8));
        panel.setLayoutParams(p);
        panel.setBackgroundColor(0xFFEFEFEF);

        CheckBox cb = new CheckBox(this);
        cb.setText("Layer " + (layer + 1) + " ON");
        cb.setTextSize(18);
        cb.setTypeface(Typeface.DEFAULT_BOLD);
        cb.setChecked(OverlayConfig.enabled(this, layer));
        cb.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                OverlayConfig.prefs(MainActivity.this).edit()
                        .putBoolean(OverlayConfig.key(layer, "enabled"), isChecked)
                        .apply();
                updateOverlay();
            }
        });
        checkBoxes[layer] = cb;
        panel.addView(cb);

        addSeek(panel, layer, 0, "Posisi X", "x", baseW, OverlayConfig.x(this, layer));
        addSeek(panel, layer, 1, "Posisi Y", "y", baseH, OverlayConfig.y(this, layer));
        addSeek(panel, layer, 2, "Lebar", "width", baseH, OverlayConfig.width(this, layer));
        addSeek(panel, layer, 3, "Panjang", "height", baseH, OverlayConfig.height(this, layer));

        root.addView(panel);
    }

    private void addSeek(LinearLayout panel, final int layer, final int index,
                         final String label, final String key, int max, int value) {
        TextView tv = text(label + ": " + value + " px", 15, false);
        tv.setPadding(0, dp(8), 0, 0);
        panel.addView(tv);
        labels[layer][index] = tv;

        SeekBar seekBar = new SeekBar(this);
        seekBar.setMax(Math.max(1, max));
        seekBar.setProgress(Math.min(Math.max(0, value), max));
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                int finalValue = progress;
                if ("width".equals(key) || "height".equals(key)) {
                    finalValue = Math.max(1, progress);
                }
                labels[layer][index].setText(label + ": " + finalValue + " px");
                OverlayConfig.prefs(MainActivity.this).edit()
                        .putInt(OverlayConfig.key(layer, key), finalValue)
                        .apply();
                if (fromUser) updateOverlay();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                updateOverlay();
            }
        });
        bars[layer][index] = seekBar;
        panel.addView(seekBar);
    }

    private void requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= 23) {
            if (!Settings.canDrawOverlays(this)) {
                Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(intent, REQ_OVERLAY);
            } else {
                Toast.makeText(this, "Izin overlay sudah aktif", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean hasOverlayPermission() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private void startOverlay() {
        if (!hasOverlayPermission()) {
            Toast.makeText(this, "Aktifkan izin overlay dulu", Toast.LENGTH_SHORT).show();
            requestOverlayPermission();
            return;
        }
        Intent intent = new Intent(this, OverlayService.class);
        intent.setAction(OverlayConfig.ACTION_START);
        startService(intent);
        Toast.makeText(this, "Overlay aktif", Toast.LENGTH_SHORT).show();
    }

    private void updateOverlay() {
        if (!hasOverlayPermission()) return;
        Intent intent = new Intent(this, OverlayService.class);
        intent.setAction(OverlayConfig.ACTION_UPDATE);
        startService(intent);
    }

    private void stopOverlay() {
        Intent intent = new Intent(this, OverlayService.class);
        intent.setAction(OverlayConfig.ACTION_STOP);
        startService(intent);
        Toast.makeText(this, "Overlay stop", Toast.LENGTH_SHORT).show();
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(s);
        tv.setTextSize(sp);
        tv.setTextColor(0xFF222222);
        if (bold) tv.setTypeface(Typeface.DEFAULT_BOLD);
        return tv;
    }

    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(56)
        );
        p.setMargins(0, dp(8), 0, dp(6));
        b.setLayoutParams(p);
        return b;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
