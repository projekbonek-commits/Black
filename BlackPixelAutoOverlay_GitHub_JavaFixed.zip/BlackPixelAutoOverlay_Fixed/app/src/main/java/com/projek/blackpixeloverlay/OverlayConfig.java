package com.projek.blackpixeloverlay;

import android.content.Context;
import android.content.SharedPreferences;

public class OverlayConfig {
    public static final int MAX_LAYERS = 4;
    public static final String PREFS = "black_pixel_overlay_prefs";

    public static final String ACTION_START = "com.projek.blackpixeloverlay.START";
    public static final String ACTION_UPDATE = "com.projek.blackpixeloverlay.UPDATE";
    public static final String ACTION_STOP = "com.projek.blackpixeloverlay.STOP";

    public static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static String key(int layer, String name) {
        return "layer_" + layer + "_" + name;
    }

    public static boolean enabled(Context context, int layer) {
        SharedPreferences p = prefs(context);
        if (layer == 0) return p.getBoolean(key(layer, "enabled"), true);
        return p.getBoolean(key(layer, "enabled"), false);
    }

    public static int x(Context context, int layer) {
        return prefs(context).getInt(key(layer, "x"), layer == 0 ? 900 : 100);
    }

    public static int y(Context context, int layer) {
        return prefs(context).getInt(key(layer, "y"), layer == 0 ? 1000 : 100);
    }

    public static int width(Context context, int layer) {
        return prefs(context).getInt(key(layer, "width"), layer == 0 ? 5 : 20);
    }

    public static int height(Context context, int layer) {
        return prefs(context).getInt(key(layer, "height"), layer == 0 ? 2000 : 100);
    }
}
