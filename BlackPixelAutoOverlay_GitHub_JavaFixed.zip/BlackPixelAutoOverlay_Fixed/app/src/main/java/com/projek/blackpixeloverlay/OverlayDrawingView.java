package com.projek.blackpixeloverlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.Display;
import android.view.Surface;
import android.view.WindowManager;
import android.view.View;

public class OverlayDrawingView extends View {
    private final Paint paint = new Paint();
    private final WindowManager windowManager;

    public OverlayDrawingView(Context context) {
        super(context);
        paint.setColor(0xFF000000);
        paint.setStyle(Paint.Style.FILL);
        windowManager = (WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
        setWillNotDraw(false);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        int viewW = getWidth();
        int viewH = getHeight();
        if (viewW <= 0 || viewH <= 0) return;

        int baseW = Math.min(viewW, viewH); // portrait width
        int baseH = Math.max(viewW, viewH); // portrait height
        int rotation = getRotationValue();

        for (int i = 0; i < OverlayConfig.MAX_LAYERS; i++) {
            if (!OverlayConfig.enabled(getContext(), i)) continue;

            int x = OverlayConfig.x(getContext(), i);
            int y = OverlayConfig.y(getContext(), i);
            int w = Math.max(1, OverlayConfig.width(getContext(), i));
            int h = Math.max(1, OverlayConfig.height(getContext(), i));

            RectF rect = transformPortraitRectToCurrentRotation(x, y, w, h, baseW, baseH, rotation);
            canvas.drawRect(rect, paint);
        }
    }

    private int getRotationValue() {
        try {
            Display display = windowManager.getDefaultDisplay();
            return display.getRotation();
        } catch (Exception e) {
            return Surface.ROTATION_0;
        }
    }

    private RectF transformPortraitRectToCurrentRotation(int x, int y, int w, int h,
                                                         int baseW, int baseH, int rotation) {
        float left;
        float top;
        float right;
        float bottom;

        if (rotation == Surface.ROTATION_90) {
            // Portrait coordinate -> landscape clockwise
            left = y;
            top = baseW - x - w;
            right = y + h;
            bottom = baseW - x;
        } else if (rotation == Surface.ROTATION_270) {
            // Portrait coordinate -> landscape counter-clockwise
            left = baseH - y - h;
            top = x;
            right = baseH - y;
            bottom = x + w;
        } else if (rotation == Surface.ROTATION_180) {
            left = baseW - x - w;
            top = baseH - y - h;
            right = baseW - x;
            bottom = baseH - y;
        } else {
            left = x;
            top = y;
            right = x + w;
            bottom = y + h;
        }

        return new RectF(left, top, right, bottom);
    }
}
