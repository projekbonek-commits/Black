package com.projekbonek.blackpixeloverlay;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final CheckBox[] checks = new CheckBox[4];
    private final EditText[] xs = new EditText[4];
    private final EditText[] ys = new EditText[4];
    private final EditText[] ws = new EditText[4];
    private final EditText[] hs = new EditText[4];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        Layer[] layers = Prefs.loadLayers(this);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(28));
        root.setBackgroundColor(Color.WHITE);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Black Pixel V2 Presisi");
        title.setTextSize(28);
        title.setTextColor(Color.BLACK);
        title.setTypeface(null, 1);
        title.setGravity(Gravity.CENTER);
        root.addView(title, lp(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("INPUT MANUAL + tombol -10/-1/+1/+10 • true black • auto rotate");
        sub.setTextSize(15);
        sub.setTextColor(Color.DKGRAY);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(6), 0, dp(18));
        root.addView(sub, lp(-1, -2));

        Button perm = makeButton("IZINKAN OVERLAY");
        perm.setOnClickListener(v -> openOverlayPermission());
        root.addView(perm, lp(-1, dp(58)));
        addSpace(root, 10);

        TextView tips = new TextView(this);
        tips.setText("Tips AMOLED: mulai Lebar 6 px, lalu kecilkan pelan-pelan. Pakai tombol +1 / -1 biar pas.");
        tips.setTextSize(14);
        tips.setTextColor(Color.rgb(80, 80, 80));
        tips.setPadding(dp(6), dp(2), dp(6), dp(10));
        root.addView(tips, lp(-1, -2));
        addSpace(root, 8);

        for (int i = 0; i < 4; i++) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(12), dp(12), dp(12));
            card.setBackgroundColor(Color.rgb(244, 244, 244));

            checks[i] = new CheckBox(this);
            checks[i].setText("Layer " + (i + 1) + " ON");
            checks[i].setTextSize(22);
            checks[i].setTextColor(Color.BLACK);
            checks[i].setTypeface(null, 1);
            checks[i].setChecked(layers[i].enabled);
            card.addView(checks[i], lp(-1, -2));

            xs[i] = addField(card, "Posisi X (px)", layers[i].x, true, false);
            ys[i] = addField(card, "Posisi Y (px)", layers[i].y, true, false);
            ws[i] = addField(card, "Lebar (px)", layers[i].w, false, true);
            hs[i] = addField(card, "Panjang/Tinggi (px)", layers[i].h, false, true);

            root.addView(card, lp(-1, -2));
            addSpace(root, 14);
        }

        Button start = makeButton("START / UPDATE OVERLAY");
        start.setBackgroundColor(Color.BLACK);
        start.setTextColor(Color.WHITE);
        start.setOnClickListener(v -> startOverlay());
        root.addView(start, lp(-1, dp(60)));

        Button stop = makeButton("STOP OVERLAY");
        stop.setBackgroundColor(Color.rgb(244, 67, 54));
        stop.setTextColor(Color.WHITE);
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
        root.addView(stop, lp(-1, dp(60)));

        TextView note = new TextView(this);
        note.setText("V2 fokus buat kalibrasi presisi. Kalau posisi masih geser, kecil-besarkan X/Y pakai tombol 1 px, bukan ngetik ulang semua.");
        note.setTextSize(13);
        note.setTextColor(Color.GRAY);
        note.setPadding(0, dp(14), 0, 0);
        root.addView(note, lp(-1, -2));

        setContentView(scroll);
    }

    private EditText addField(LinearLayout parent, String label, int value, boolean withTenStep, boolean isSizeField) {
        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(16);
        tv.setTextColor(Color.DKGRAY);
        tv.setPadding(0, dp(8), 0, dp(3));
        parent.addView(tv, lp(-1, -2));

        EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        et.setSingleLine(true);
        et.setText(String.valueOf(value));
        et.setTextSize(20);
        et.setSelectAllOnFocus(true);
        parent.addView(et, lp(-1, dp(54)));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(2), 0, dp(8));
        if (withTenStep) {
            row.addView(makeAdjustButton(et, "-10", -10, isSizeField), weightLp());
        }
        row.addView(makeAdjustButton(et, "-1", -1, isSizeField), weightLp());
        row.addView(makeAdjustButton(et, "+1", 1, isSizeField), weightLp());
        if (withTenStep) {
            row.addView(makeAdjustButton(et, "+10", 10, isSizeField), weightLp());
        } else {
            row.addView(makeAdjustButton(et, "-5", -5, isSizeField), weightLp());
            row.addView(makeAdjustButton(et, "+5", 5, isSizeField), weightLp());
        }
        parent.addView(row, lp(-1, -2));
        return et;
    }

    private Button makeAdjustButton(EditText et, String text, int delta, boolean isSizeField) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setOnClickListener(v -> {
            int current = readInt(et, 0);
            int next = current + delta;
            if (isSizeField && next < 1) next = 1;
            et.setText(String.valueOf(next));
            et.setSelection(et.getText().length());
        });
        return b;
    }

    private void startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlayPermission();
            Toast.makeText(this, "Aktifkan izin overlay dulu", Toast.LENGTH_LONG).show();
            return;
        }
        Layer[] layers = new Layer[4];
        for (int i = 0; i < 4; i++) {
            layers[i] = new Layer(
                    checks[i].isChecked(),
                    readInt(xs[i], 0),
                    readInt(ys[i], 0),
                    Math.max(1, readInt(ws[i], 1)),
                    Math.max(1, readInt(hs[i], 1))
            );
        }
        Prefs.saveLayers(this, layers);
        Intent intent = new Intent(this, OverlayService.class);
        stopService(intent);
        startService(intent);
        Toast.makeText(this, "Overlay jalan / update", Toast.LENGTH_SHORT).show();
    }

    private int readInt(EditText et, int def) {
        try {
            String s = et.getText().toString().trim();
            if (s.isEmpty()) return def;
            return Integer.parseInt(s);
        } catch (Exception e) {
            return def;
        }
    }

    private void openOverlayPermission() {
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivity(i);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams weightLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        return p;
    }

    private void addSpace(LinearLayout root, int dp) {
        View v = new View(this);
        root.addView(v, lp(-1, dp(dp)));
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(0, dp(4), 0, dp(4));
        return p;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
