package com.projekbonek.blackpixeloverlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.Surface;
import android.view.View;

public class OverlayDrawingView extends View {
    private final Paint paint = new Paint();
    private Layer[] layers;

    public OverlayDrawingView(Context context) {
        super(context);
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.FILL);
        paint.setAlpha(255);
        paint.setAntiAlias(false);
        paint.setDither(false);
        paint.setFilterBitmap(false);
        setBackgroundColor(Color.TRANSPARENT);
        layers = Prefs.loadLayers(context);
    }

    public void reload() {
        layers = Prefs.loadLayers(getContext());
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        final int cw = getWidth();
        final int ch = getHeight();
        if (cw <= 0 || ch <= 0) return;

        final int portraitW = Math.min(cw, ch);
        final int portraitH = Math.max(cw, ch);
        int rot = Surface.ROTATION_0;
        try {
            if (getDisplay() != null) rot = getDisplay().getRotation();
        } catch (Exception ignored) {}

        for (Layer layer : layers) {
            if (layer == null || !layer.enabled) continue;
            int[] r = transform(layer.x, layer.y, layer.w, layer.h, portraitW, portraitH, rot);
            canvas.drawRect(r[0], r[1], r[2], r[3], paint);
        }
    }

    private int[] transform(int x, int y, int w, int h, int pw, int ph, int rot) {
        w = Math.max(1, w);
        h = Math.max(1, h);
        int left, top, right, bottom;

        switch (rot) {
            case Surface.ROTATION_90:
                left = ph - (y + h);
                top = x;
                right = left + h;
                bottom = top + w;
                break;
            case Surface.ROTATION_180:
                left = pw - (x + w);
                top = ph - (y + h);
                right = left + w;
                bottom = top + h;
                break;
            case Surface.ROTATION_270:
                left = y;
                top = pw - (x + w);
                right = left + h;
                bottom = top + w;
                break;
            case Surface.ROTATION_0:
            default:
                left = x;
                top = y;
                right = x + w;
                bottom = y + h;
                break;
        }
        return new int[]{left, top, right, bottom};
    }
}
