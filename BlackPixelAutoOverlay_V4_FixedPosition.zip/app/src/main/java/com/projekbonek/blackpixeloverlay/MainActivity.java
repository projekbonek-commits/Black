package com.projekbonek.blackpixeloverlay;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final CheckBox[] checks = new CheckBox[4];
    private final EditText[] xs = new EditText[4];
    private final EditText[] ys = new EditText[4];
    private final EditText[] ws = new EditText[4];
    private final EditText[] hs = new EditText[4];

    private static final int MAX_XY = 1300;
    private static final int MAX_SIZE_SMALL = 120;
    private static final int MAX_HEIGHT = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        Layer[] layers = Prefs.loadLayers(this);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(18), dp(16), dp(26));
        root.setBackgroundColor(Color.WHITE);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("Black Pixel V4 Fixed Position");
        title.setTextSize(25);
        title.setTextColor(Color.BLACK);
        title.setTypeface(null, 1);
        title.setGravity(Gravity.CENTER);
        root.addView(title, lp(-1, -2));

        TextView sub = new TextView(this);
        sub.setText("Slider + input + posisi tidak digeser saat rotate");
        sub.setTextSize(15);
        sub.setTextColor(Color.DKGRAY);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(6), 0, dp(14));
        root.addView(sub, lp(-1, -2));

        Button perm = makeButton("IZINKAN OVERLAY");
        perm.setOnClickListener(v -> openOverlayPermission());
        root.addView(perm, lp(-1, dp(56)));

        Button topApply = makeButton("START / UPDATE OVERLAY");
        topApply.setBackgroundColor(Color.BLACK);
        topApply.setTextColor(Color.WHITE);
        topApply.setOnClickListener(v -> startOverlay());
        root.addView(topApply, lp(-1, dp(56)));

        TextView tips = new TextView(this);
        tips.setText("Mode ini TIDAK menghitung ulang posisi saat HP rotate. Garis overlay dikunci di X/Y yang sama, biar ngikut garis panel yang tetap di tempat.");
        tips.setTextSize(14);
        tips.setTextColor(Color.rgb(80, 80, 80));
        tips.setPadding(dp(4), dp(10), dp(4), dp(8));
        root.addView(tips, lp(-1, -2));
        addSpace(root, 8);

        for (int i = 0; i < 4; i++) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(12), dp(12), dp(12));
            card.setBackgroundColor(Color.rgb(244, 244, 244));

            checks[i] = new CheckBox(this);
            checks[i].setText("Layer " + (i + 1) + " ON");
            checks[i].setTextSize(22);
            checks[i].setTextColor(Color.BLACK);
            checks[i].setTypeface(null, 1);
            checks[i].setChecked(layers[i].enabled);
            card.addView(checks[i], lp(-1, -2));

            xs[i] = addSliderField(card, "Posisi X", layers[i].x, 0, MAX_XY, false, true);
            ys[i] = addSliderField(card, "Posisi Y", layers[i].y, 0, MAX_XY, false, true);
            ws[i] = addSliderField(card, "Lebar", layers[i].w, 1, MAX_SIZE_SMALL, true, false);
            hs[i] = addSliderField(card, "Panjang/Tinggi", layers[i].h, 1, MAX_HEIGHT, true, false);

            Button applyLayer = makeButton("UPDATE LAYER " + (i + 1));
            applyLayer.setBackgroundColor(Color.rgb(45, 45, 45));
            applyLayer.setTextColor(Color.WHITE);
            applyLayer.setOnClickListener(v -> startOverlay());
            card.addView(applyLayer, lp(-1, dp(46)));

            root.addView(card, lp(-1, -2));
            addSpace(root, 14);
        }

        Button start = makeButton("START / UPDATE OVERLAY");
        start.setBackgroundColor(Color.BLACK);
        start.setTextColor(Color.WHITE);
        start.setOnClickListener(v -> startOverlay());
        root.addView(start, lp(-1, dp(60)));

        Button stop = makeButton("STOP OVERLAY");
        stop.setBackgroundColor(Color.rgb(244, 67, 54));
        stop.setTextColor(Color.WHITE);
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
        root.addView(stop, lp(-1, dp(60)));

        setContentView(scroll);
    }

    private EditText addSliderField(LinearLayout parent, String label, int value, int min, int max, boolean isSize, boolean bigStep) {
        TextView tv = new TextView(this);
        tv.setText(label + ": " + value + " px");
        tv.setTextSize(16);
        tv.setTextColor(Color.DKGRAY);
        tv.setPadding(0, dp(8), 0, dp(2));
        parent.addView(tv, lp(-1, -2));

        EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        et.setSingleLine(true);
        et.setText(String.valueOf(value));
        et.setTextSize(20);
        et.setSelectAllOnFocus(true);
        parent.addView(et, lp(-1, dp(50)));

        SeekBar bar = new SeekBar(this);
        int safeMax = Math.max(max, value + 100);
        bar.setMax(safeMax - min);
        bar.setProgress(clamp(value, min, safeMax) - min);
        parent.addView(bar, lp(-1, dp(42)));

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(2), 0, dp(8));

        if (bigStep) {
            row.addView(makeAdjustButton(et, bar, tv, label, min, "-10", -10), weightLp());
        } else {
            row.addView(makeAdjustButton(et, bar, tv, label, min, "-5", -5), weightLp());
        }
        row.addView(makeAdjustButton(et, bar, tv, label, min, "-1", -1), weightLp());
        row.addView(makeAdjustButton(et, bar, tv, label, min, "+1", 1), weightLp());
        if (bigStep) {
            row.addView(makeAdjustButton(et, bar, tv, label, min, "+10", 10), weightLp());
        } else {
            row.addView(makeAdjustButton(et, bar, tv, label, min, "+5", 5), weightLp());
        }
        parent.addView(row, lp(-1, -2));

        et.addTextChangedListener(new TextWatcher() {
            private boolean lock = false;
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable e) {
                if (lock) return;
                int v = readInt(et, min);
                if (isSize && v < 1) v = 1;
                tv.setText(label + ": " + v + " px");
                if (v > min + bar.getMax()) {
                    bar.setMax((v + 100) - min);
                }
                int p = clamp(v, min, min + bar.getMax()) - min;
                bar.setProgress(p);
            }
        });

        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) {
                    int v = progress + min;
                    et.setText(String.valueOf(v));
                    et.setSelection(et.getText().length());
                    tv.setText(label + ": " + v + " px");
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        return et;
    }

    private Button makeAdjustButton(EditText et, SeekBar bar, TextView tv, String label, int min, String text, int delta) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setOnClickListener(v -> {
            int current = readInt(et, min);
            int next = current + delta;
            if (next < min) next = min;
            if (next > min + bar.getMax()) {
                bar.setMax((next + 100) - min);
            }
            et.setText(String.valueOf(next));
            et.setSelection(et.getText().length());
            tv.setText(label + ": " + next + " px");
            bar.setProgress(next - min);
        });
        return b;
    }

    private void startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlayPermission();
            Toast.makeText(this, "Aktifkan izin overlay dulu", Toast.LENGTH_LONG).show();
            return;
        }
        Layer[] layers = new Layer[4];
        for (int i = 0; i < 4; i++) {
            layers[i] = new Layer(
                    checks[i].isChecked(),
                    readInt(xs[i], 0),
                    readInt(ys[i], 0),
                    Math.max(1, readInt(ws[i], 1)),
                    Math.max(1, readInt(hs[i], 1))
            );
        }
        Prefs.saveLayers(this, layers);
        Intent intent = new Intent(this, OverlayService.class);
        stopService(intent);
        startService(intent);
        Toast.makeText(this, "Overlay update", Toast.LENGTH_SHORT).show();
    }

    private int readInt(EditText et, int def) {
        try {
            String s = et.getText().toString().trim();
            if (s.isEmpty()) return def;
            return Integer.parseInt(s);
        } catch (Exception e) {
            return def;
        }
    }

    private int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private void openOverlayPermission() {
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivity(i);
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams weightLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(42), 1f);
        p.setMargins(dp(3), 0, dp(3), 0);
        return p;
    }

    private void addSpace(LinearLayout root, int dp) {
        View v = new View(this);
        root.addView(v, lp(-1, dp(dp)));
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(0, dp(3), 0, dp(3));
        return p;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
