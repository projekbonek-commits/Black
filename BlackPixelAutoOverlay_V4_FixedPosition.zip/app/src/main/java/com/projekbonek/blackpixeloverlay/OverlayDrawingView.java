package com.projekbonek.blackpixeloverlay;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class OverlayDrawingView extends View {
    private final Paint paint = new Paint();
    private Layer[] layers;

    public OverlayDrawingView(Context context) {
        super(context);
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.FILL);
        paint.setAlpha(255);
        paint.setAntiAlias(false);
        paint.setDither(false);
        paint.setFilterBitmap(false);
        setBackgroundColor(Color.TRANSPARENT);
        layers = Prefs.loadLayers(context);
    }

    public void reload() {
        layers = Prefs.loadLayers(getContext());
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        for (Layer layer : layers) {
            if (layer == null || !layer.enabled) continue;
            int w = Math.max(1, layer.w);
            int h = Math.max(1, layer.h);

            // V4: NO ROTATION TRANSFORM.
            // X/Y dipakai apa adanya. Jadi saat HP rotate, app tidak memindahkan
            // garis overlay ke koordinat hasil hitung ulang.
            canvas.drawRect(layer.x, layer.y, layer.x + w, layer.y + h, paint);
        }
    }
}
