package com.projekbonek.blackpixeloverlay;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {
    public static final String NAME = "black_pixel_overlay_prefs";

    public static Layer[] loadLayers(Context ctx) {
        SharedPreferences sp = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE);
        Layer[] layers = new Layer[4];
        for (int i = 0; i < 4; i++) {
            boolean defEnabled = i == 0;
            int defX = i == 0 ? 901 : 0;
            int defY = 0;
            int defW = i == 0 ? 6 : 2;
            int defH = i == 0 ? 2400 : 100;
            layers[i] = new Layer(
                    sp.getBoolean("l" + i + "_enabled", defEnabled),
                    sp.getInt("l" + i + "_x", defX),
                    sp.getInt("l" + i + "_y", defY),
                    sp.getInt("l" + i + "_w", defW),
                    sp.getInt("l" + i + "_h", defH)
            );
        }
        return layers;
    }

    public static void saveLayers(Context ctx, Layer[] layers) {
        SharedPreferences.Editor ed = ctx.getSharedPreferences(NAME, Context.MODE_PRIVATE).edit();
        for (int i = 0; i < layers.length; i++) {
            ed.putBoolean("l" + i + "_enabled", layers[i].enabled);
            ed.putInt("l" + i + "_x", layers[i].x);
            ed.putInt("l" + i + "_y", layers[i].y);
            ed.putInt("l" + i + "_w", Math.max(1, layers[i].w));
            ed.putInt("l" + i + "_h", Math.max(1, layers[i].h));
        }
        ed.apply();
    }
}
