package com.projekbonek.blackpixeloverlay;

public class Layer {
    public boolean enabled;
    public int x;
    public int y;
    public int w;
    public int h;

    public Layer(boolean enabled, int x, int y, int w, int h) {
        this.enabled = enabled;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
    }
}
