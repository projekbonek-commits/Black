package com.projekbonek.blackpixeloverlay;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final CheckBox[] checks = new CheckBox[4];
    private final EditText[] xs = new EditText[4];
    private final EditText[] ys = new EditText[4];
    private final EditText[] ws = new EditText[4];
    private final EditText[] hs = new EditText[4];

    private int portraitW = 1080;
    private int portraitH = 2400;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        readScreenSize();
        buildUi();
    }

    private void readScreenSize() {
        try {
            DisplayMetrics dm = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getRealMetrics(dm);
            portraitW = Math.min(dm.widthPixels, dm.heightPixels);
            portraitH = Math.max(dm.widthPixels, dm.heightPixels);
        } catch (Exception ignored) {}
    }

    private void buildUi() {
        Layer[] layers = Prefs.loadLayers(this);

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(20), dp(18), dp(28));
        root.setBackgroundColor(Color.WHITE);
        scroll.addView(root);

        TextView title = text("Black Pixel V6 Rotasi Dibalik", 28, Color.BLACK, true);
        title.setGravity(Gravity.CENTER);
        root.addView(title, lp(-1, -2));

        TextView sub = text("slider + input angka • arah landscape dibalik", 15, Color.DKGRAY, false);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(6), 0, dp(18));
        root.addView(sub, lp(-1, -2));

        TextView mode = text("MODE AKTIF: IKUT ROTASI PIXEL, ARAH LANDSCAPE DIBALIK. Pakai ini kalau V5 kebalik arah.", 14, Color.rgb(70, 70, 70), false);
        mode.setPadding(dp(8), dp(8), dp(8), dp(8));
        mode.setBackgroundColor(Color.rgb(238, 238, 238));
        root.addView(mode, lp(-1, -2));

        Button perm = makeButton("IZINKAN OVERLAY");
        perm.setOnClickListener(v -> openOverlayPermission());
        root.addView(perm, lp(-1, dp(58)));
        addSpace(root, 10);

        for (int i = 0; i < 4; i++) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(12), dp(12), dp(12), dp(12));
            card.setBackgroundColor(Color.rgb(244, 244, 244));

            checks[i] = new CheckBox(this);
            checks[i].setText("Layer " + (i + 1) + " ON");
            checks[i].setTextSize(22);
            checks[i].setTextColor(Color.BLACK);
            checks[i].setTypeface(null, 1);
            checks[i].setChecked(layers[i].enabled);
            card.addView(checks[i], lp(-1, -2));

            xs[i] = addSliderInput(card, "Posisi X portrait (px)", layers[i].x, 0, portraitW, true);
            ys[i] = addSliderInput(card, "Posisi Y portrait (px)", layers[i].y, 0, portraitH, true);
            ws[i] = addSliderInput(card, "Lebar garis (px)", layers[i].w, 1, 80, false);
            hs[i] = addSliderInput(card, "Panjang/Tinggi garis (px)", layers[i].h, 1, portraitH, false);

            root.addView(card, lp(-1, -2));
            addSpace(root, 14);
        }

        Button start = makeButton("START / UPDATE OVERLAY");
        start.setBackgroundColor(Color.BLACK);
        start.setTextColor(Color.WHITE);
        start.setOnClickListener(v -> startOverlay());
        root.addView(start, lp(-1, dp(60)));

        Button stop = makeButton("STOP OVERLAY");
        stop.setBackgroundColor(Color.rgb(244, 67, 54));
        stop.setTextColor(Color.WHITE);
        stop.setOnClickListener(v -> stopService(new Intent(this, OverlayService.class)));
        root.addView(stop, lp(-1, dp(60)));

        TextView note = text("Pakai slider buat posisi kasar, lalu tombol -1/+1 buat presisi. Kalibrasi utamanya di portrait dulu, habis itu rotate ke landscape.", 13, Color.GRAY, false);
        note.setPadding(0, dp(14), 0, 0);
        root.addView(note, lp(-1, -2));

        setContentView(scroll);
    }

    private EditText addSliderInput(LinearLayout parent, String label, int value, int min, int max, boolean tenStep) {
        if (max < min) max = min + 1;
        value = clamp(value, min, max);

        TextView tv = text(label, 16, Color.DKGRAY, false);
        tv.setPadding(0, dp(8), 0, dp(3));
        parent.addView(tv, lp(-1, -2));

        EditText et = new EditText(this);
        et.setInputType(InputType.TYPE_CLASS_NUMBER);
        et.setSingleLine(true);
        et.setText(String.valueOf(value));
        et.setTextSize(20);
        et.setSelectAllOnFocus(true);
        parent.addView(et, lp(-1, dp(50)));

        SeekBar bar = new SeekBar(this);
        bar.setMax(max - min);
        bar.setProgress(value - min);
        parent.addView(bar, lp(-1, dp(42)));

        final boolean[] lock = new boolean[]{false};
        final int fMin = min;
        final int fMax = max;

        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser || lock[0]) return;
                lock[0] = true;
                et.setText(String.valueOf(fMin + progress));
                et.setSelection(et.getText().length());
                lock[0] = false;
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        et.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                if (lock[0]) return;
                try {
                    int v = Integer.parseInt(s.toString());
                    if (v >= fMin && v <= fMax) {
                        lock[0] = true;
                        bar.setProgress(v - fMin);
                        lock[0] = false;
                    }
                } catch (Exception ignored) {}
            }
        });

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(0, dp(2), 0, dp(8));
        if (tenStep) row.addView(makeAdjustButton(et, bar, "-10", -10, min, max), weightLp());
        row.addView(makeAdjustButton(et, bar, "-1", -1, min, max), weightLp());
        row.addView(makeAdjustButton(et, bar, "+1", 1, min, max), weightLp());
        if (tenStep) {
            row.addView(makeAdjustButton(et, bar, "+10", 10, min, max), weightLp());
        } else {
            row.addView(makeAdjustButton(et, bar, "-5", -5, min, max), weightLp());
            row.addView(makeAdjustButton(et, bar, "+5", 5, min, max), weightLp());
        }
        parent.addView(row, lp(-1, -2));
        return et;
    }

    private Button makeAdjustButton(EditText et, SeekBar bar, String text, int delta, int min, int max) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setOnClickListener(v -> {
            int current = readInt(et, min);
            int next = clamp(current + delta, min, max);
            et.setText(String.valueOf(next));
            et.setSelection(et.getText().length());
            bar.setProgress(next - min);
        });
        return b;
    }

    private void startOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            openOverlayPermission();
            Toast.makeText(this, "Aktifkan izin overlay dulu", Toast.LENGTH_LONG).show();
            return;
        }
        Layer[] layers = new Layer[4];
        for (int i = 0; i < 4; i++) {
            layers[i] = new Layer(
                    checks[i].isChecked(),
                    readInt(xs[i], 0),
                    readInt(ys[i], 0),
                    Math.max(1, readInt(ws[i], 1)),
                    Math.max(1, readInt(hs[i], 1))
            );
        }
        Prefs.saveLayers(this, layers);
        Intent intent = new Intent(this, OverlayService.class);
        stopService(intent);
        startService(intent);
        Toast.makeText(this, "Overlay V6 / update", Toast.LENGTH_SHORT).show();
    }

    private int readInt(EditText et, int def) {
        try {
            String s = et.getText().toString().trim();
            if (s.isEmpty()) return def;
            return Integer.parseInt(s);
        } catch (Exception e) {
            return def;
        }
    }

    private int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    private void openOverlayPermission() {
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivity(i);
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, 1);
        return t;
    }

    private Button makeButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(16);
        b.setAllCaps(false);
        return b;
    }

    private LinearLayout.LayoutParams weightLp() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(44), 1f);
        p.setMargins(dp(4), 0, dp(4), 0);
        return p;
    }

    private void addSpace(LinearLayout root, int dp) {
        View v = new View(this);
        root.addView(v, lp(-1, dp(dp)));
    }

    private LinearLayout.LayoutParams lp(int w, int h) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(0, dp(4), 0, dp(4));
        return p;
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
